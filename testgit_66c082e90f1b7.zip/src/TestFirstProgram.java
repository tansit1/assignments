import data.*;

public class TestFirstProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         System.out.println("5555");
         Point p = new Point();
         p.x =17;
         p.y =27 ;
         System.out.println(p.y);
         
         
         
         
	}

}
