package data;

public class Point {
	public int x;
	public int y;

}
